( function( $ ) {
	'use strict';

	/* global redPartsSputnik */

	const sputnik = redPartsSputnik;
	function init( elements ) {
		$( elements ).each( function() {
			initSingle( this );
		} );
	}
	function initSingle( element ) {
		$( element ).find( '.owl-carousel' ).owlCarousel( {
			items: 1,
			nav: false,
			dots: true,
			loop: true,
			startPosition: $( element ).data( 'start-position' ),
			rtl: sputnik.isRtl(),
		} );
	}

	$( function() {
		sputnik.initWidget( 'redparts_sputnik_block_slideshow', '.th-block-slideshow', init );
	} );
}( jQuery ) );
