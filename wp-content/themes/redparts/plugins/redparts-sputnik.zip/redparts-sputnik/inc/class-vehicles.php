<?php
/**
 * RedParts sputnik vehicles.
 *
 * @package RedParts\Sputnik
 * @since 1.0.0
 * @noinspection SqlResolve
 */

namespace RedParts\Sputnik;

use WP_Term;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Vehicles' ) ) {
	/**
	 * Class Vehicles.
	 *
	 * @package RedParts\Sputnik
	 */
	class Vehicles extends Singleton {
		/**
		 * Form fields.
		 *
		 * @var array
		 */
		protected static $fields = array();

		/**
		 * Form fields.
		 *
		 * @var array
		 */
		protected static $admin_fields = array();

		/**
		 * Initialization.
		 */
		public function init() {
			// The priority is 100 so that Redux has time to initialize.
			add_action( 'after_setup_theme', array( $this, 'deferred_init' ), 100 );
		}

		/**
		 * Deferred initialization.
		 */
		public function deferred_init() {
			if ( 'yes' !== Settings::instance()->get( 'autoparts_features' ) ) {
				return;
			}

			self::$fields       = array_values( Settings::instance()->get( 'vehicle_fields' ) );
			self::$admin_fields = array();

			foreach ( self::$fields as $field2 ) {
				if ( 'year' === $field2['type'] ) {
					self::$admin_fields[] = array(
						'name'  => 'redparts_' . $field2['slug'] . '_since',
						// translators: %s field name, for example: Year.
						'title' => sprintf( esc_html__( 'Vehicle %s (since)', 'redparts-sputnik' ), $field2['label'] ),
					);
					self::$admin_fields[] = array(
						'name'  => 'redparts_' . $field2['slug'] . '_until',
						// translators: %s field name, for example: Year.
						'title' => sprintf( esc_html__( 'Vehicle %s (until)', 'redparts-sputnik' ), $field2['label'] ),
					);
				} else {
					self::$admin_fields[] = array(
						'name'  => 'redparts_' . $field2['slug'],
						// translators: %s field name, for example: Model.
						'title' => sprintf( esc_html__( 'Vehicle %s', 'redparts-sputnik' ), $field2['label'] ),
					);
				}
			}

			if ( 'yes' === Settings::instance()->get( 'search_vehicles_by_vin' ) ) {
				self::$admin_fields[] = array(
					'name'  => 'redparts_vin',
					'title' => esc_html__( 'Vehicle VIN', 'redparts-sputnik' ),
				);
			}

			$attribute_slug = $this->get_attribute_slug();

			if ( $attribute_slug ) {
				add_action( $attribute_slug . '_add_form_fields', array( $this, 'add_form_fields' ) );
				add_action( $attribute_slug . '_edit_form_fields', array( $this, 'edit_form_fields' ) );
				add_action( 'create_' . $attribute_slug, array( $this, 'save_form' ) );
				add_action( 'edit_' . $attribute_slug, array( $this, 'save_form' ) );
			}

			add_shortcode( 'redparts_sputnik_vehicle_select', array( $this, 'vehicle_select_shortcode' ) );
			add_shortcode( 'redparts_sputnik_vehicle_form', array( $this, 'vehicle_form_shortcode' ) );

			if ( 'yes' === Settings::instance()->get( 'search_vehicles_by_vin' ) ) {
				add_shortcode( 'redparts_sputnik_vehicle_vin', array( $this, 'vehicle_vin_shortcode' ) );
			}

			if ( ! wp_doing_ajax() ) {
				return;
			}

			add_action( 'wp_ajax_redparts_sputnik_vehicle_select_load_data', array( $this, 'ajax_vehicle_select_load_data' ) );
			add_action( 'wp_ajax_nopriv_redparts_sputnik_vehicle_select_load_data', array( $this, 'ajax_vehicle_select_load_data' ) );

			if ( 'yes' === Settings::instance()->get( 'search_vehicles_by_vin' ) ) {
				add_action( 'wp_ajax_redparts_sputnik_vehicle_vin_load_data', array( $this, 'ajax_vehicle_vin_load_data' ) );
				add_action( 'wp_ajax_nopriv_redparts_sputnik_vehicle_vin_load_data', array( $this, 'ajax_vehicle_vin_load_data' ) );
			}
		}

		/**
		 * Returns the vehicle attribute slug.
		 *
		 * @return string|null
		 * @noinspection PhpMissingReturnTypeInspection
		 */
		public function get_attribute_slug() {
			if ( ! function_exists( 'wc_attribute_taxonomy_name' ) ) {
				return null;
			}

			$attribute_name = Settings::instance()->get( 'vehicle_attribute' );

			if ( empty( $attribute_name ) ) {
				return null;
			}

			return sanitize_key( wc_attribute_taxonomy_name( $attribute_name ) );
		}

		/**
		 * Returns the filter name of the vehicle attribute.
		 *
		 * @return string
		 * @noinspection PhpMissingReturnTypeInspection
		 */
		public function get_attribute_filter_name() {
			$attribute_name = Settings::instance()->get( 'vehicle_attribute' );

			if ( empty( $attribute_name ) ) {
				return '';
			}

			return 'filter_' . $attribute_name;
		}

		/**
		 * Adds an additional fields to the vehicle add form.
		 */
		public function add_form_fields() {
			foreach ( self::$admin_fields as $field ) {
				?>
				<div class="form-field term-<?php echo esc_attr( $field['name'] ); ?>-wrap">
					<label for="tag-<?php echo esc_attr( $field['name'] ); ?>">
						<?php echo esc_html( $field['title'] ); ?>
					</label>
					<input
						name="<?php echo esc_attr( $field['name'] ); ?>"
						id="tag-<?php echo esc_attr( $field['name'] ); ?>"
						type="text"
						value=""
					>
				</div>
				<?php
			}
		}

		/**
		 * Adds an additional fields to the vehicle edit form.
		 *
		 * @param WP_Term $term WordPress term object.
		 */
		public function edit_form_fields( WP_Term $term ) {
			foreach ( self::$admin_fields as $field ) {
				$field_value = get_term_meta( $term->term_id, $field['name'], true );
				?>
				<tr class="form-field term-<?php echo esc_attr( $field['name'] ); ?>-wrap">
					<th scope="row">
						<label for="<?php echo esc_attr( $field['name'] ); ?>">
							<?php echo esc_html( $field['title'] ); ?>
						</label>
					</th>
					<td>
						<input
							name="<?php echo esc_attr( $field['name'] ); ?>"
							id="<?php echo esc_attr( $field['name'] ); ?>"
							type="text"
							value="<?php echo esc_attr( $field_value ); ?>"
						>
					</td>
				</tr>
				<?php
			}
		}

		/**
		 * Saves vehicle meta fields.
		 *
		 * @param integer $term_id Term ID.
		 */
		public function save_form( int $term_id ) {
			foreach ( self::$admin_fields as $field ) {
				if ( ! isset( $_POST[ $field['name'] ] ) ) {
					return;
				}
			}

			if ( ! current_user_can( 'edit_term', $term_id ) ) {
				return;
			}
			if ( ! isset( $_POST['_wpnonce'] ) && ! isset( $_POST['_wpnonce_add-tag'] ) ) {
				return;
			}

			// Sanitization here would be redundant.
			// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if (
				! wp_verify_nonce( wp_unslash( $_POST['_wpnonce_add-tag'] ), 'add-tag' )
				&& ! wp_verify_nonce( wp_unslash( $_POST['_wpnonce'] ), 'update-tag_' . $term_id )
			) {
				return;
			}
			// phpcs:enable

			foreach ( self::$admin_fields as $field ) {
				$produced_since = sanitize_text_field( wp_unslash( $_POST[ $field['name'] ] ) );

				update_term_meta( $term_id, $field['name'], $produced_since );
			}
		}

		/**
		 * Shortcode that returns the vehicle selection control.
		 *
		 * @param array $args Arguments.
		 *
		 * @return string
		 * @noinspection DuplicatedCode
		 */
		public function vehicle_select_shortcode( $args = array() ): string {
			$args = shortcode_atts(
				array(
					'class'    => '',
					'location' => '',
				),
				$args
			);

			$classes = array(
				'th-vehicle-select',
			);

			if ( ! empty( $args['class'] ) ) {
				$classes[] = $args['class'];
			}
			if ( ! empty( $args['location'] ) ) {
				$classes[] = 'th-vehicle-select--location--' . $args['location'];
			}

			ob_start();

			?>
			<div
				class="<?php echo esc_attr( join( ' ', $classes ) ); ?>"
				data-ajax-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
				data-nonce="<?php echo esc_attr( wp_create_nonce( 'redparts_sputnik_vehicle_select_load_data' ) ); ?>"
			>
				<div class="th-vehicle-select__body">
					<?php foreach ( self::$fields as $index => $field ) : ?>
						<?php

						$options      = 0 === $index ? $this->get_options( array() ) : array();
						$item_classes = array( 'th-vehicle-select__item' );

						if ( 0 !== $index ) {
							$item_classes[] = 'th-vehicle-select__item--disabled';
						}

						?>
						<div
							class="<?php echo esc_attr( implode( ' ', $item_classes ) ); ?>"
							data-label="<?php echo esc_attr( $field['label'] ); ?>"
						>
							<select
								class="th-vehicle-select__item-control"
								name="<?php echo esc_attr( $field['slug'] ); ?>"
								aria-label="<?php echo esc_attr( $field['label'] ); ?>"
								<?php disabled( 0 !== $index ); ?>
							>
								<option value="null"><?php echo esc_html( $field['placeholder'] ); ?></option>
								<?php foreach ( $options as $option ) : ?>
									<option value="<?php echo esc_attr( wp_json_encode( $option['value'] ) ); ?>">
										<?php echo esc_html( $option['title'] ); ?>
									</option>
								<?php endforeach; ?>
							</select>
							<div class="th-vehicle-select__item-loader"></div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<?php

			return ob_get_clean();
		}

		/**
		 * Shortcode that returns a control for selecting a vehicle by VIN.
		 *
		 * @param array $args Arguments.
		 *
		 * @return string
		 */
		public function vehicle_vin_shortcode( $args = array() ): string {
			$args = shortcode_atts(
				array(
					'class' => '',
				),
				$args
			);

			$classes = array(
				'th-vehicle-vin',
			);

			if ( ! empty( $args['class'] ) ) {
				$classes[] = $args['class'];
			}

			ob_start();
			?>
			<div
				class="<?php echo esc_attr( join( ' ', $classes ) ); ?>"
				data-ajax-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
				data-nonce="<?php echo esc_attr( wp_create_nonce( 'redparts_sputnik_vehicle_vin_load_data' ) ); ?>"
			>
				<div class="th-vehicle-vin__field">
					<input
						type="text"
						placeholder="<?php echo esc_attr__( 'Enter VIN number', 'redparts-sputnik' ); ?>"
						aria-label="<?php echo esc_attr__( 'VIN number', 'redparts-sputnik' ); ?>"
					>
					<div class="th-vehicle-vin__loader"></div>
				</div>
				<div class="th-vehicle-vin__alert"></div>
			</div>
			<?php

			return ob_get_clean();
		}

		/**
		 * Shortcode that returns a vehicle selection form.
		 *
		 * @param array $args Arguments.
		 *
		 * @return string
		 */
		public function vehicle_form_shortcode( $args = array() ): string {
			$args = shortcode_atts(
				array(
					'class'    => '',
					'location' => '',
				),
				$args
			);

			$location = $args['location'];
			$classes  = array(
				'th-vehicle-form',
			);

			if ( ! empty( $args['class'] ) ) {
				$classes[] = $args['class'];
			}
			if ( ! empty( $location ) ) {
				$classes[] = 'th-vehicle-form--location--' . $location;
			}

			ob_start();

			?>
			<div class="<?php echo esc_attr( join( ' ', $classes ) ); ?>">
				<div class="th-vehicle-form__body">
					<?php echo do_shortcode( '[redparts_sputnik_vehicle_select class="th-vehicle-form__vehicle-select" location="' . esc_attr( $location ) . '"]' ); ?>

					<?php if ( 'yes' === Settings::instance()->get( 'search_vehicles_by_vin' ) ) : ?>
						<div class="th-vehicle-form__divider">
							<?php echo esc_html__( 'Or', 'redparts-sputnik' ); ?>
						</div>

						<?php echo do_shortcode( '[redparts_sputnik_vehicle_vin class="th-vehicle-form__vin"]' ); ?>
					<?php endif; ?>
				</div>
			</div>
			<?php

			return ob_get_clean();
		}

		/**
		 * Returns data for vehicle select controls.
		 */
		public function ajax_vehicle_select_load_data() {
			if (
				! isset( $_POST['nonce'] ) ||
				! wp_verify_nonce(
					sanitize_key( wp_unslash( $_POST['nonce'] ) ),
					'redparts_sputnik_vehicle_select_load_data'
				)
			) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'Action failed. Please refresh the page and retry.', 'redparts-sputnik' ),
					)
				);
			}

			if ( ! isset( $_POST['data']['for'] ) ) {
				wp_send_json_error();
			}

			$data_for = sanitize_text_field( wp_unslash( $_POST['data']['for'] ) );

			$index = -1;

			foreach ( self::$fields as $field_index => $field ) {
				if ( $data_for === $field['slug'] ) {
					$index = $field_index;
					break;
				}
			}

			if ( -1 === $index ) {
				wp_send_json_error();
			}

			$values        = array();
			$fields_before = array_slice( self::$fields, 0, $index );

			foreach ( $fields_before as $field ) {
				if ( ! isset( $_POST['data']['values'][ $field['slug'] ] ) ) {
					wp_send_json_error();
				}

				$values[] = sanitize_text_field(
					wp_unslash( $_POST['data']['values'][ $field['slug'] ] )
				);
			}

			$options = $this->get_options( $values );

			wp_send_json_success( $options );
		}

		/**
		 * Returns vehicle by VIN.
		 */
		public function ajax_vehicle_vin_load_data() {
			if (
				! isset( $_POST['nonce'] ) ||
				! wp_verify_nonce(
					sanitize_key( wp_unslash( $_POST['nonce'] ) ),
					'redparts_sputnik_vehicle_vin_load_data'
				)
			) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'Action failed. Please refresh the page and retry.', 'redparts-sputnik' ),
					)
				);
			}

			if ( ! isset( $_POST['data']['vin'] ) ) {
				wp_send_json_error();
			}

			$vin = sanitize_text_field( wp_unslash( $_POST['data']['vin'] ) );

			// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			$rows = get_terms(
				array(
					'taxonomy'   => $this->get_attribute_slug(),
					'number'     => 1,
					'hide_empty' => false,
					'meta_query' => array(
						'relation' => 'AND',
						array(
							'key'     => 'redparts_vin',
							'value'   => $vin,
							'compare' => '=',
						),
					),
				)
			);
			// phpcs:enable

			if ( $rows ) {
				$row = $rows[0];

				$vehicle = $this->get_vehicle_by_id( $row->term_id );

				wp_send_json_success(
					array(
						'vehicle' => $vehicle,
						'message' => sprintf(
							// translators: Vehicle %s name.
							esc_html__( 'Found: %s', 'redparts-sputnik' ),
							self::get_vehicle_name( $vehicle )
						),
					)
				);
			}

			wp_send_json_error(
				array(
					'message' => esc_html__( 'We were unable to find a vehicle. Perhaps you specified an incorrect VIN.', 'redparts-sputnik' ),
				)
			);
		}

		/**
		 * Returns options for the vehicle picker selects.
		 *
		 * @param array $values An array of filled selects values.
		 *
		 * @return array
		 */
		public function get_options( array $values ): array {
			global $wpdb;

			$fields          = array_slice( self::$fields, 0, count( $values ) + 1 );
			$return_vehicles = count( $values ) === count( self::$fields ) - 1;

			$join_statements     = array();
			$join_placeholders   = array();
			$select_statements   = array();
			$select_placeholders = array();
			$where_statements    = array();
			$where_placeholders  = array();

			if ( $return_vehicles ) {
				$select_statements[] = 'tt.term_id AS id';
			}

			$where_statements[]   = "t.slug != '__all__'";
			$where_statements[]   = 'tt.taxonomy = %s';
			$where_placeholders[] = $this->get_attribute_slug();

			foreach ( $fields as $index => $field ) {
				$slug = $field['slug'];

				$last_field = count( $fields ) === $index + 1;

				if ( 'year' === $field['type'] ) {
					$tm1 = 'tm' . ( count( $join_statements ) + 1 );
					$tm2 = 'tm' . ( count( $join_statements ) + 2 );

					$join_statements[] = "LEFT JOIN $wpdb->termmeta AS $tm1 ON tt.term_id = $tm1.term_id AND $tm1.meta_key = %s";
					$join_statements[] = "LEFT JOIN $wpdb->termmeta AS $tm2 ON tt.term_id = $tm2.term_id AND $tm2.meta_key = %s";

					$join_placeholders[] = 'redparts_' . $slug . '_since';
					$join_placeholders[] = 'redparts_' . $slug . '_until';

					if ( $last_field || $return_vehicles ) {
						$select_statements[] = "$tm1.meta_value AS %s";
						$select_statements[] = "IF($tm2.meta_value = '', '9999', $tm2.meta_value) AS %s";

						$select_placeholders[] = 'field_' . $slug . '_since';
						$select_placeholders[] = 'field_' . $slug . '_until';
					}

					if ( ! $last_field ) {
						$where_statements[]   = "$tm1.meta_value <= %d AND ($tm2.meta_value >= %d OR $tm2.meta_value = '')";
						$where_placeholders[] = $values[ $index ];
						$where_placeholders[] = $values[ $index ];
					}
				} else {
					$tm = 'tm' . ( count( $join_statements ) + 1 );

					$join_statements[]   = "LEFT JOIN $wpdb->termmeta AS $tm ON tt.term_id = $tm.term_id AND $tm.meta_key = %s";
					$join_placeholders[] = 'redparts_' . $slug;

					if ( $last_field || $return_vehicles ) {
						$select_statements[] = "$tm.meta_value AS %s";

						$select_placeholders[] = 'field_' . $slug;
					}

					if ( ! $last_field ) {
						$where_statements[]   = "$tm.meta_value = %s";
						$where_placeholders[] = $values[ $index ];
					}
				}
			}

			$select_statements = implode( ", \n", $select_statements );
			$join_statements   = implode( "\n", $join_statements );
			$where_statements  = implode( " AND\n", $where_statements );

			$placeholders = array_merge(
				$select_placeholders,
				$join_placeholders,
				$where_placeholders
			);

			$sql = "
				SELECT DISTINCT
				$select_statements
				FROM $wpdb->term_taxonomy AS tt
				LEFT JOIN $wpdb->terms AS t ON tt.term_id = t.term_id
				$join_statements
				WHERE
				$where_statements
			";

			// phpcs:disable WordPress.DB.DirectDatabaseQuery
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, ...$placeholders ), ARRAY_A );
			// phpcs:enable

			$last_field      = $fields[ count( $fields ) - 1 ];
			$last_field_slug = 'field_' . $last_field['slug'];

			$result = array();

			if ( ! $return_vehicles ) {
				if ( 'year' === $last_field['type'] ) {
					$years = array();

					foreach ( $rows as $row ) {
						$since = absint( $row[ $last_field_slug . '_since' ] );
						$until = absint( '9999' === $row[ $last_field_slug . '_until' ] ? gmdate( 'Y' ) : $row[ $last_field_slug . '_until' ] );

						if ( 100 < $until - $since ) {
							continue;
						}

						foreach ( range( $since, $until ) as $year ) {
							if ( ! in_array( $year, $years, true ) ) {
								$years[] = $year;
							}
						}
					}

					$result = array_map(
						function( $year ) {
							return array(
								'title' => $year,
								'value' => $year,
							);
						},
						$years
					);
				} else {
					foreach ( $rows as $row ) {
						$result[] = array(
							'title' => $row[ $last_field_slug ],
							'value' => $row[ $last_field_slug ],
						);
					}
				}
			} else {
				foreach ( $rows as $row ) {
					$link  = get_term_link( (int) $row['id'], $this->get_attribute_slug() );
					$value = array_merge(
						$row,
						array(
							'link' => $link,
						)
					);

					$result[] = array(
						'title' => $row[ $last_field_slug ],
						'value' => $value,
					);
				}
			}

			array_multisort( array_column( $result, 'title' ), SORT_ASC, $result );

			return $result;
		}

		/**
		 * Returns vehicle by specified field.
		 *
		 * @param string $field Name of the field by which the car will be found..
		 * @param mixed  $value Field value.
		 *
		 * @return array|null
		 * @noinspection PhpMissingReturnTypeInspection
		 */
		public function get_vehicle_by( string $field, $value ) {
			$attribute_slug = $this->get_attribute_slug();

			if ( ! $attribute_slug ) {
				return null;
			}

			$term = get_term_by( $field, $value, $attribute_slug );

			if ( ! $term ) {
				return null;
			}

			$vehicle = array(
				'id'   => $term->term_id,
				'slug' => $term->slug,
				'vin'  => get_term_meta( $term->term_id, 'redparts_vin', true ),
			);

			foreach ( self::$fields as $field ) {
				$key = 'field_' . $field['slug'];

				if ( 'year' === $field['type'] ) {
					$vehicle[ $key . '_since' ] = get_term_meta( $term->term_id, 'redparts_' . $field['slug'] . '_since', true );
					$vehicle[ $key . '_until' ] = get_term_meta( $term->term_id, 'redparts_' . $field['slug'] . '_until', true );
				} else {
					$vehicle[ $key ] = get_term_meta( $term->term_id, 'redparts_' . $field['slug'], true );
				}
			}

			return $vehicle;
		}

		/**
		 * Returns vehicle by specified ID.
		 *
		 * @param int $vehicle_id Vehicle ID.
		 *
		 * @return array|null
		 * @noinspection PhpMissingReturnTypeInspection
		 */
		public function get_vehicle_by_id( int $vehicle_id ) {
			return $this->get_vehicle_by( 'id', absint( $vehicle_id ) );
		}

		/**
		 * Returns vehicle name.
		 *
		 * @param array $vehicle Vehicle.
		 *
		 * @return string
		 */
		public static function get_vehicle_name( array $vehicle ): string {
			return apply_filters(
				'redparts_sputnik_get_vehicle_name',
				self::apply_vehicle_fields( $vehicle, self::get_vehicle_name_template() )
			);
		}

		/**
		 * Returns vehicle description.
		 *
		 * @param array $vehicle Vehicle.
		 *
		 * @return string
		 */
		public static function get_vehicle_description( array $vehicle ): string {
			return apply_filters(
				'redparts_sputnik_get_vehicle_description',
				self::apply_vehicle_fields( $vehicle, self::get_vehicle_description_template() )
			);
		}

		/**
		 * Returns the vehicle name template.
		 *
		 * @return string
		 */
		public static function get_vehicle_name_template(): string {
			return apply_filters(
				'redparts_sputnik_get_vehicle_name_template',
				Settings::instance()->get( 'vehicle_name', '' )
			);
		}

		/**
		 * Returns the vehicle name template.
		 *
		 * @return string
		 */
		public static function get_vehicle_description_template(): string {
			return apply_filters(
				'redparts_sputnik_get_vehicle_description_template',
				Settings::instance()->get( 'vehicle_description', '' )
			);
		}

		/**
		 * Applies vehicle field values to the template.
		 *
		 * @param array  $vehicle  - Vehicle data.
		 * @param string $template - Template.
		 *
		 * @return string
		 */
		private static function apply_vehicle_fields( array $vehicle, string $template ): string {
			foreach ( self::$fields as $field ) {
				if ( 'year' === $field['type'] ) {
					$template = str_replace( '%' . $field['slug'] . '%', $vehicle[ 'field_' . $field['slug'] . '_since' ], $template );
					$template = str_replace( '%' . $field['slug'] . '_since%', $vehicle[ 'field_' . $field['slug'] . '_since' ], $template );
					$template = str_replace( '%' . $field['slug'] . '_until%', $vehicle[ 'field_' . $field['slug'] . '_until' ], $template );
				} else {
					$template = str_replace( '%' . $field['slug'] . '%', $vehicle[ 'field_' . $field['slug'] ], $template );
				}
			}

			return $template;
		}
	}
}
